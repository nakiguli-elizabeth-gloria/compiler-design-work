import re
from dataclasses import dataclass


# Keywords - reserved words that cannot be used as identifiers
KEYWORDS = {
    'GENE', 'STUDY', 'RNA_TRANSCRIBE', 'GC_CONTENT', 'LENGTH',
    'IF', 'THEN', 'END', 'REPORT',
    'MULTIPLY', 'ADD', 'SUBTRACT', 'DIVIDE'
}

# These are valid as identifiers even though they match keywords in uppercase
CONDITION_VARS = {'gc_content', 'length', 'if'}


# Token patterns in priority order
TOKEN_PATTERNS = [
    ('NEWLINE',     r'\n'),
    ('WS',          r'[ \t]+'),
    ('COMMENT',     r'--[^\n]*'),
    ('KEYWORD',     r'\b(?:' + '|'.join(sorted(KEYWORDS, key=len, reverse=True)) + r')\b'),
    ('DNA_LITERAL', r'"[^"\n]*"'),
    ('NUMBER',      r'\d+(?:\.\d+)?'),
    ('OPERATOR',    r'>=|<=|==|!=|>|<'),
    ('ASSIGN',      r'='),
    ('COLON',       r':'),
    ('IDENTIFIER',  r'[A-Za-z_][A-Za-z0-9_]*'),
    ('ERROR',       r'.'),
]

# Compile all patterns into one master regex
MASTER_RE = re.compile(
    '|'.join(f'(?P<{name}>{pat})' for name, pat in TOKEN_PATTERNS)
)


@dataclass
class Token:
    type:  str
    value: str
    line:  int
    col:   int

    def __repr__(self):
        return (f'Token({self.type:<14} {self.value!r:<24} '
                f'line {self.line}, col {self.col})')


class LexError(Exception):
    def __str__(self):
        return super().__str__()


class Lexer:
    """Converts raw GenLang source text into a list of Token objects."""

    def __init__(self, source: str):
        self.source = source
        self.tokens: list[Token]    = []
        self.errors: list[LexError] = []

    def _get_suggestion(self, char: str) -> str:
        """Provide helpful suggestion for common mistakes."""
        suggestions = {
            '@': 'Python decorator syntax is not valid in GenLang. Remove @.',
            '#': 'Comments in GenLang use -- instead of #',
            ';': 'Semicolons are not needed in GenLang',
            '{': 'GenLang uses : and END instead of { }',
            '}': 'GenLang uses : and END instead of { }',
        }
        
        if char in suggestions:
            return f"Hint: {suggestions[char]}"
        
        if char.isalpha():
            upper_char = char.upper()
            for keyword in KEYWORDS:
                if keyword.startswith(upper_char) or upper_char in keyword:
                    return f"Hint: Unknown word '{char}'. Did you mean '{keyword}'?"
            
            return f"Hint: '{char}' is not a valid character in GenLang"
        
        return f"Hint: Unexpected character '{char}'. Only letters, digits, _, =, <, >, :, and quotes are allowed."

    def tokenise(self) -> list[Token]:
        line, col = 1, 1

        for match in MASTER_RE.finditer(self.source):
            kind  = match.lastgroup
            value = match.group()
            tok   = Token(kind, value, line, col)

            # Update position counters
            if kind == 'NEWLINE':
                line += 1
                col   = 1
                continue
            elif kind in ('WS', 'COMMENT'):
                col += len(value)
                continue

            col += len(value)

            # Unrecognised character - record error with suggestion
            if kind == 'ERROR':
                suggestion = self._get_suggestion(value)
                self.errors.append(
                    LexError(
                        f"Line {tok.line}, col {tok.col}: "
                        f"unexpected character '{value}'\n"
                        f"    {suggestion}"
                    )
                )
                continue

            # conflict of identifier with reserved keyword

            if kind == 'IDENTIFIER':
                if value.upper() in KEYWORDS and value not in CONDITION_VARS:
                    self.errors.append(
                        LexError(
                            f"Line {tok.line}, col {tok.col}: "
                            f"'{value}' is a reserved keyword and cannot be used as an identifier\n"
                            f"    Hint: Use a different name like '{value.lower()}_gene' or 'my_{value.lower()}'"
                        )
                    )
                    continue

            self.tokens.append(tok)
        return self.tokens