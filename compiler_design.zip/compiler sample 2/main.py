"""
main.py — GenLang Compiler Driver
====================================
Entry point for the GenLang compiler frontend.

Ties together all three compiler phases:
  Phase 1 → lexer.py        (Lexical Analysis)
  Phase 2 → parser.py       (Syntax Analysis + AST)
  Phase 3 → semantic.py     (Semantic Analysis)
           ast_printer.py   (AST display)

Run all test cases:
  python main.py

Compile your own source:
  from main import compile_genlang
  result = compile_genlang(source_code, "my label")
"""

from lexer       import Lexer
from parser      import Parser
from semantic    import SemanticAnalyser
from ast_printer import ASTPrinter
from test_cases  import ALL_TEST_CASES


# ─────────────────────────────────────────────────────────────────────
# COMPILER DRIVER
# ─────────────────────────────────────────────────────────────────────

def compile_genlang(source: str, label: str = 'GenLang') -> dict:
    """
    Run all three compiler frontend phases on a GenLang source string.

    Returns a dict with:
      tokens       — list of Token objects
      lex_errors   — list of LexError
      ast          — ProgramNode (or None if parse failed)
      parse_errors — list of ParseError
      sem_errors   — list of SemanticError
      sem_info     — list of analysis result strings
      success      — True only if all three phases pass with zero errors

    Args:
      source — the GenLang source code string
      label  — a label printed in the output header
    """

    results = {
        'tokens':       [],
        'lex_errors':   [],
        'ast':          None,
        'parse_errors': [],
        'sem_errors':   [],
        'sem_info':     [],
        'success':      False,
    }

    _print_header(label)

    # ══════════════════════════════════════════════════════════════
    # PHASE 1 — LEXICAL ANALYSIS
    # ══════════════════════════════════════════════════════════════
    _print_phase(1, 'LEXICAL ANALYSIS')

    lexer  = Lexer(source)
    tokens = lexer.tokenise()
    results['tokens']     = tokens
    results['lex_errors'] = lexer.errors

    # Print every token
    for tok in tokens:
        marker = '  ✗ ERROR' if tok.type == 'ERROR' else '  ·'
        print(f"{marker}  {tok.type:<14} {tok.value!r:<26} "
              f"line {tok.line}, col {tok.col}")

    # Report lexical errors
    if lexer.errors:
        print(f"\n  ✗ LEXICAL ERRORS ({len(lexer.errors)}):")
        for err in lexer.errors:
            print(f"    → {err}")
        print("\n  ✗ Cannot proceed to parsing — fix lexical errors first.")
        _print_result(False)
        return results

    print(f"\n  ✓ {len(tokens)} tokens produced — no lexical errors")

    # ══════════════════════════════════════════════════════════════
    # PHASE 2 — SYNTAX ANALYSIS
    # ══════════════════════════════════════════════════════════════
    _print_phase(2, 'SYNTAX ANALYSIS  [recursive descent parser]')

    parser = Parser(tokens)
    ast    = parser.parse()
    results['ast']          = ast
    results['parse_errors'] = parser.errors

    # Print the AST
    print("\n  Abstract Syntax Tree:")
    ast_lines = ASTPrinter().print(ast).split('\n')
    for line in ast_lines:
        print(f"    {line}")

    # Report parse errors
    if parser.errors:
        print(f"\n  ✗ PARSE ERRORS ({len(parser.errors)}):")
        for err in parser.errors:
            print(f"    → {err}")
        print("\n  ✗ Cannot proceed to semantic analysis — fix syntax errors first.")
        _print_result(False)
        return results

    print(f"\n  ✓ Parse successful — AST built")

    # ══════════════════════════════════════════════════════════════
    # PHASE 3 — SEMANTIC ANALYSIS
    # ══════════════════════════════════════════════════════════════
    _print_phase(3, 'SEMANTIC ANALYSIS')

    analyser = SemanticAnalyser(ast)
    analyser.analyse()
    results['sem_errors'] = analyser.errors
    results['sem_info']   = analyser.info

    # Print symbol table
    print("\n  Symbol Table (declared genes):")
    if analyser.symbol_table:
        for name, gene in analyser.symbol_table.items():
            gc = analyser._gc_percent(gene.sequence)
            print(f"    {name!r:15} → '{gene.sequence}'"
                  f"  ({len(gene.sequence)} bp, GC={gc:.1f}%)")
    else:
        print("    (empty)")

    # Print analysis results
    print("\n  Analysis Results:")
    for line in analyser.info:
        print(f"  {line}")

    # Print warnings
    for warning in analyser.warnings:
        print(f"  ⚠  {warning}")

    # Print semantic errors
    for err in analyser.errors:
        print(f"  ✗  {err}")

    # Final result
    if not analyser.errors:
        results['success'] = True
        warn_note = (f" ({len(analyser.warnings)} warning(s))"
                     if analyser.warnings else "")
        print(f"\n  ✓ Semantic analysis passed{warn_note}")
    else:
        print(f"\n  ✗ {len(analyser.errors)} semantic error(s) found")

    _print_result(results['success'])
    return results


# ─────────────────────────────────────────────────────────────────────
# PRINT HELPERS
# ─────────────────────────────────────────────────────────────────────

def _print_header(label: str):
    print(f"\n{'█' * 66}")
    print(f"  {label}")
    print(f"{'█' * 66}")

def _print_phase(n: int, title: str):
    print(f"\n{'─' * 66}")
    print(f"  PHASE {n} — {title}")
    print(f"{'─' * 66}")

def _print_result(success: bool):
    status = '✓ COMPILED OK' if success else '✗ ERRORS FOUND'
    print(f"\n  RESULT: {status}")


# ─────────────────────────────────────────────────────────────────────
# ENTRY POINT — run all test cases
# ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    passed = 0
    failed = 0

    for label, source in ALL_TEST_CASES:
        result = compile_genlang(source, label)
        if result['success']:
            passed += 1
        else:
            failed += 1

    # Summary
    print(f"\n{'═' * 66}")
    print(f"  TEST SUMMARY")
    print(f"{'═' * 66}")
    print(f"  Total : {len(ALL_TEST_CASES)}")
    print(f"  Passed: {passed}")
    print(f"  Failed (expected): {failed}")
    print(f"\n  Note: TC2–TC6 are expected to fail — they demonstrate")
    print(f"  error detection. TC1, TC7, TC8, TC9 should compile OK.")
    print(f"{'═' * 66}\n")
