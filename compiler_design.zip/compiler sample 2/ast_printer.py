"""
ast_printer.py — Abstract Syntax Tree Pretty Printer
======================================================
Updated with RNA_TRANSCRIBE (replaced COMPLEMENT)
"""

from parser import (
    ProgramNode, GeneDecl, StudyBlock, ASTNode,
    RNATranscribeNode, GCContentNode, LengthNode,
    ReportNode, MultiplyNode, AddNode, SubtractNode, DivideNode,
    ConditionalNode
)


class ASTPrinter:
    """Recursively walks the AST and renders it as an indented tree."""

    def print(self, program: ProgramNode) -> str:
        lines = []
        lines.append('ProgramNode')
        self._print_genes(program.genes, lines, prefix='')
        self._print_studies(program.studies, lines, prefix='')
        return '\n'.join(lines)

    def _print_genes(self, genes, lines, prefix):
        if not genes:
            lines.append(f'{prefix}└── Genes (0)')
            return
        
        lines.append(f'{prefix}├── Genes ({len(genes)})')
        child_prefix = prefix + '│   '

        for i, gene in enumerate(genes):
            is_last = i == len(genes) - 1
            c = '└──' if is_last else '├──'
            lines.append(
                f'{child_prefix}{c} GENE {gene.name} = "{gene.sequence}"'
            )

    def _print_studies(self, studies, lines, prefix):
        if not studies:
            lines.append(f'{prefix}└── Studies (0)')
            return
        
        lines.append(f'{prefix}└── Studies ({len(studies)})')
        child_prefix = prefix + '    '

        for i, study in enumerate(studies):
            is_last = i == len(studies) - 1
            c = '└──' if is_last else '├──'
            lines.append(f'{child_prefix}{c} STUDY {study.target}')

            stmt_prefix = child_prefix + ('    ' if is_last else '│   ')
            self._print_statements(study.statements, lines, stmt_prefix)

    def _print_statements(self, stmts, lines, prefix):
        if not stmts:
            lines.append(f'{prefix}└── (no statements)')
            return
            
        for i, stmt in enumerate(stmts):
            is_last = i == len(stmts) - 1
            c = '└──' if is_last else '├──'
            self._print_node(stmt, lines, prefix, c)

    def _print_node(self, node, lines, prefix, connector):
        if isinstance(node, RNATranscribeNode):
            lines.append(f'{prefix}{connector} RNA_TRANSCRIBE')

        elif isinstance(node, GCContentNode):
            lines.append(f'{prefix}{connector} GC_CONTENT')

        elif isinstance(node, LengthNode):
            lines.append(f'{prefix}{connector} LENGTH')

        elif isinstance(node, ReportNode):
            lines.append(f'{prefix}{connector} REPORT "{node.message}"')

        elif isinstance(node, MultiplyNode):
            lines.append(f'{prefix}{connector} MULTIPLY {node.count}')

        elif isinstance(node, AddNode):
            lines.append(f'{prefix}{connector} ADD {node.gene_name}')

        elif isinstance(node, SubtractNode):
            lines.append(f'{prefix}{connector} SUBTRACT {node.count}')

        elif isinstance(node, DivideNode):
            lines.append(f'{prefix}{connector} DIVIDE {node.parts}')

        elif isinstance(node, ConditionalNode):
            lines.append(
                f'{prefix}{connector} IF {node.variable} '
                f'{node.operator} {node.value}'
            )
            child_prefix = prefix + ('    ' if connector == '└──' else '│   ')

            lines.append(f'{child_prefix}├── THEN')
            then_prefix = child_prefix + '│   '
            if node.body:
                self._print_node(node.body, lines, then_prefix, '└──')

            lines.append(f'{child_prefix}└── END')

        else:
            lines.append(f'{prefix}{connector} {type(node).__name__}')