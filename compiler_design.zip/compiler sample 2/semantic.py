"""
semantic.py — Phase 3: Semantic Analysis
Enhanced error reporting with line/col numbers
"""

from parser import (
    ProgramNode, GeneDecl, StudyBlock, ASTNode,
    RNATranscribeNode, GCContentNode, LengthNode,
    ReportNode, MultiplyNode, AddNode, SubtractNode, DivideNode,
    ConditionalNode
)


VALID_BASES = set('ATCG')
COND_VARS = {'gc_content', 'length'}


class SemanticError(Exception):
    def __init__(self, message: str, line: int = -1, col: int = -1, suggestion: str = ""):
        self.message = message
        self.line = line
        self.col = col
        self.suggestion = suggestion
        location = f"Line {line}, col {col}: " if line > 0 else ""
        full_msg = f"{location}{message}"
        if suggestion:
            full_msg += f"\n    💡 {suggestion}"
        super().__init__(full_msg)


class SemanticAnalyser:
    def __init__(self, ast: ProgramNode):
        self.ast = ast
        self.errors = []
        self.warnings = []
        self.info = []
        self.symbol_table = {}
        self.current_seq = ""
        self.current_study = ""
        self.invalid_genes = set()  # ✅ Track genes with errors

    def analyse(self):
        self._check_gene_declarations()
        self._check_study_blocks()
        return self

    def _check_gene_declarations(self):
        for gene in self.ast.genes:
            # Check for duplicate
            if gene.name in self.symbol_table:
                self.errors.append(SemanticError(
                    f"Gene '{gene.name}' declared multiple times",
                    line=-1, col=-1,
                    suggestion=f"Remove or rename one of the declarations. First seen at line {self.symbol_table[gene.name]}"
                ))
                continue

            # Store with line info
            self.symbol_table[gene.name] = gene

            # Check empty sequence
            if not gene.sequence:
                self.errors.append(SemanticError(
                    f"Gene '{gene.name}' has an empty sequence",
                    line=-1, col=-1,
                    suggestion="DNA sequences cannot be empty. Use e.g., \"ATCG\""
                ))
                self.invalid_genes.add(gene.name)  # ✅ Mark as invalid
                continue

            # Validate DNA sequence
            invalid = sorted({c for c in gene.sequence.upper() if c not in VALID_BASES})
            if invalid:
                self.errors.append(SemanticError(
                    f"Gene '{gene.name}' contains invalid base(s): {invalid}",
                    line=-1, col=-1,
                    suggestion=f"Valid bases are A, T, C, G. Remove: {', '.join(invalid)}"
                ))
                self.invalid_genes.add(gene.name)  # ✅ Mark as invalid
            else:
                gc = self._gc_percent(gene.sequence)
                self.info.append(
                    f"  ✓ GENE '{gene.name}': {len(gene.sequence)} bp, GC={gc:.1f}%"
                )

    def _check_study_blocks(self):
        for block in self.ast.studies:
            self.current_study = block.target
            
            # Check if gene exists
            if block.target not in self.symbol_table:
                self.errors.append(SemanticError(
                    f"STUDY '{block.target}' references undeclared gene",
                    line=-1, col=-1,
                    suggestion=f"Add 'GENE {block.target} = \"<sequence>\"' before this STUDY"
                ))
                continue

            # ✅ NEW: Check if gene has errors before processing
            if block.target in self.invalid_genes:
                self.errors.append(SemanticError(
                    f"STUDY '{block.target}' cannot proceed - gene has errors",
                    line=-1, col=-1,
                    suggestion=f"Fix the errors in GENE '{block.target}' first"
                ))
                continue

            seq = self.symbol_table[block.target].sequence.upper()
            self.current_seq = seq
            
            self.info.append(f"\n  📊 STUDY '{block.target}':")
            self.info.append(f"     Initial: {self.current_seq}")
            
            # Check if study has statements
            if not block.statements:
                self.errors.append(SemanticError(
                    f"STUDY '{block.target}' has no statements",
                    line=-1, col=-1,
                    suggestion="Add at least one operation (RNA_TRANSCRIBE, LENGTH, etc.)"
                ))
                continue
            
            for stmt in block.statements:
                self._check_statement(stmt)

    def _check_statement(self, stmt: ASTNode):
        if isinstance(stmt, RNATranscribeNode):
            self.current_seq = self._rna_transcribe(self.current_seq)
            self.info.append(f"     ✓ RNA_TRANSCRIBE → {self.current_seq}")

        elif isinstance(stmt, GCContentNode):
            gc = self._gc_percent(self.current_seq)
            self.info.append(f"     ✓ GC_CONTENT → {gc:.1f}%")

        elif isinstance(stmt, LengthNode):
            self.info.append(f"     ✓ LENGTH → {len(self.current_seq)} bp")

        elif isinstance(stmt, ReportNode):
            self.info.append(f"     ✓ REPORT: '{stmt.message}'")

        elif isinstance(stmt, MultiplyNode):
            self._check_multiply(stmt)

        elif isinstance(stmt, AddNode):
            self._check_add(stmt)

        elif isinstance(stmt, SubtractNode):
            self._check_subtract(stmt)

        elif isinstance(stmt, DivideNode):
            self._check_divide(stmt)

        elif isinstance(stmt, ConditionalNode):
            self._check_conditional(stmt)

    def _check_multiply(self, stmt: MultiplyNode):
        if stmt.count <= 0:
            self.errors.append(SemanticError(
                f"MULTIPLY {stmt.count} is invalid in STUDY '{self.current_study}'",
                line=-1, col=-1,
                suggestion=f"Use a positive integer (1, 2, 3, ...). Current sequence length: {len(self.current_seq)}"
            ))
            return
        
        self.current_seq = self.current_seq * stmt.count
        self.info.append(f"     ✓ MULTIPLY {stmt.count} → {len(self.current_seq)} bp total")

    def _check_add(self, stmt: AddNode):
        if stmt.gene_name not in self.symbol_table:
            self.errors.append(SemanticError(
                f"Cannot ADD '{stmt.gene_name}' in STUDY '{self.current_study}'",
                line=-1, col=-1,
                suggestion=f"Gene '{stmt.gene_name}' not declared. Add 'GENE {stmt.gene_name} = \"<sequence>\"'"
            ))
            return
        
        other_seq = self.symbol_table[stmt.gene_name].sequence.upper()
        
        # Validate other gene
        invalid = [c for c in other_seq if c not in VALID_BASES]
        if invalid:
            self.errors.append(SemanticError(
                f"Cannot ADD gene '{stmt.gene_name}' - contains invalid bases: {invalid}",
                line=-1, col=-1,
                suggestion=f"Fix the sequence of '{stmt.gene_name}' first"
            ))
            return
        
        self.current_seq = self.current_seq + other_seq
        self.info.append(f"     ✓ ADD {stmt.gene_name} → {len(self.current_seq)} bp total")

    def _check_subtract(self, stmt: SubtractNode):
        if stmt.count <= 0:
            self.errors.append(SemanticError(
                f"SUBTRACT {stmt.count} is invalid",
                line=-1, col=-1,
                suggestion="Use a positive integer (1, 2, 3, ...)"
            ))
            return
        
        if stmt.count > len(self.current_seq):
            self.errors.append(SemanticError(
                f"SUBTRACT {stmt.count} from sequence of length {len(self.current_seq)}",
                line=-1, col=-1,
                suggestion=f"Cannot remove more bases than exist. Maximum subtract is {len(self.current_seq)}"
            ))
            return
        
        self.current_seq = self.current_seq[:-stmt.count]
        self.info.append(f"     ✓ SUBTRACT {stmt.count} → {len(self.current_seq)} bp remaining")

    def _check_divide(self, stmt: DivideNode):
        if stmt.parts <= 0:
            self.errors.append(SemanticError(
                f"DIVIDE {stmt.parts} is invalid",
                line=-1, col=-1,
                suggestion="Use a positive integer (2, 3, 4, ...)"
            ))
            return
        
        if len(self.current_seq) % stmt.parts != 0:
            divisors = [d for d in range(2, len(self.current_seq)+1) if len(self.current_seq) % d == 0]
            self.errors.append(SemanticError(
                f"Sequence length {len(self.current_seq)} not divisible by {stmt.parts}",
                line=-1, col=-1,
                suggestion=f"Choose a divisor of {len(self.current_seq)}: {divisors if divisors else 'none (sequence is prime)'}"
            ))
            return
        
        part_length = len(self.current_seq) // stmt.parts
        self.current_seq = self.current_seq[:part_length]
        self.info.append(f"     ✓ DIVIDE {stmt.parts} → {len(self.current_seq)} bp (first part)")

    def _check_conditional(self, stmt: ConditionalNode):
        if stmt.variable not in COND_VARS:
            self.errors.append(SemanticError(
                f"Unknown condition variable '{stmt.variable}'",
                line=-1, col=-1,
                suggestion=f"Use 'gc_content' or 'length'. Available: {', '.join(COND_VARS)}"
            ))
            return

        actual = (self._gc_percent(self.current_seq)
                  if stmt.variable == 'gc_content'
                  else len(self.current_seq))

        if stmt.variable == 'gc_content' and not (0 <= stmt.value <= 100):
            self.errors.append(SemanticError(
                f"GC content threshold {stmt.value} is out of range",
                line=-1, col=-1,
                suggestion="GC percentage must be between 0 and 100"
            ))
            return

        result = self._eval_op(actual, stmt.operator, stmt.value)
        display = (f"{actual:.1f}%" if stmt.variable == 'gc_content' else str(actual))

        self.info.append(
            f"     ✓ IF {stmt.variable} {stmt.operator} {stmt.value}: "
            f"actual={display} → {'TRUE ✓ (executing)' if result else 'FALSE ✗ (skipping)'}"
        )

        if result and stmt.body:
            self._check_statement(stmt.body)

    def _rna_transcribe(self, seq: str) -> str:
        """Convert DNA to RNA by replacing T with U"""
        return seq.upper().replace('T', 'U')

    def _gc_percent(self, seq: str) -> float:
        if not seq:
            return 0.0
        seq_upper = seq.upper()
        gc_count = sum(1 for base in seq_upper if base in ('G', 'C'))
        return (gc_count / len(seq_upper)) * 100

    def _eval_op(self, actual: float, op: str, threshold: float) -> bool:
        ops = {
            '>': actual > threshold,
            '<': actual < threshold,
            '>=': actual >= threshold,
            '<=': actual <= threshold,
            '==': actual == threshold,
            '!=': actual != threshold,
        }
        return ops.get(op, False)