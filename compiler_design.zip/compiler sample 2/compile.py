"""
compile.py — GenLang Compiler
==============================
Run: python compile.py
Type your code, press Enter twice to compile.

Examples to try:
  GENE x = "ATCG"
  STUDY x:
      RNA_TRANSCRIBE
  END

Or try mistakes:
  DNA = ATCG
  GENE x = "ATCGZ"
"""

from lexer import Lexer
from parser import Parser
from semantic import SemanticAnalyser
from ast_printer import ASTPrinter


def compile_genlang(source):
    """Compile and show results."""
    
    # Phase 1: Lexer
    lexer = Lexer(source)
    tokens = lexer.tokenise()
    
    if lexer.errors:
        print(f"\n❌ LEXICAL ERRORS: {len(lexer.errors)}")
        for err in lexer.errors:
            print(f"  → {err}")
        return
    
    print(f"✓ Lexer passed: {len(tokens)} tokens")
    
    # Print all tokens
    print(f"\n TOKENS:")
    for i, token in enumerate(tokens):
        print(f"  [{i}] {token}")
    
    # Phase 2: Parser
    parser = Parser(tokens)
    ast = parser.parse()
    
    if parser.errors:
        print(f"\n⚠️  PARSE ERRORS: {len(parser.errors)}")
        for err in parser.errors:
            print(f"  → {err}")
        
    print(f"✓ Parser complete")
    
    # Phase 3: Semantic Analysis
    analyser = SemanticAnalyser(ast)
    analyser.analyse()
    
    if analyser.errors:
        print(f"\n❌ SEMANTIC ERRORS: {len(analyser.errors)}")
        for err in analyser.errors:
            print(f"  → {err}")
    
    if analyser.warnings:
        print(f"\n WARNINGS: {len(analyser.warnings)}")
        for warn in analyser.warnings:
            print(f"  → {warn}")
    
    # Show AST
    print(f"\n ABSTRACT SYNTAX TREE:")
    print(ASTPrinter().print(ast))
    
    # Show analysis
    if analyser.info:
        print(f"\n ANALYSIS:")
        for line in analyser.info:
            print(f"  {line}")
    
    total = len(lexer.errors) + len(parser.errors) + len(analyser.errors)
    print("\n" + "="*50)
    if total == 0:
        print("✓ COMPILATION SUCCESSFUL!")
    else:
        print(f"✗ {total} ERROR(S) FOUND")
    print("="*50)


if __name__ == '__main__':
    print("\n" + "="*50)
    print("  The GenLang Compiler")
    print("="*50)
    
    lines = []
    
    print("\nEnter code (press Enter twice to compile):")
    
    while True:
        try:
            line = input()
            if line == "":
                break
            lines.append(line)
        except EOFError:
            break
        except KeyboardInterrupt:
            print("\n\nCancelled.")
            exit()
    
    if lines:
        source = '\n'.join(lines)
        
        print("\n" + "="*50)
        print("  YOUR CODE:")
        print("="*50)
        for l in lines:
            print(f"  {l}")
        
        compile_genlang(source)
    else:
        print("\nNo code entered.")
        print("\nTry copying and pasting this example:\n")
        print('GENE x = "ATCG"')
        print("STUDY x:")
        print("    RNA_TRANSCRIBE")
        print("    GC_CONTENT")
        print("END")
        print("\nThen press ENTER twice to compile.")