"""
test_cases.py — GenLang Test Programs
=======================================
Essential tests for core functionality and error detection
"""

# ─────────────────────────────────────────────────────────────────────
# WORKING TESTS (Should compile successfully)
# ─────────────────────────────────────────────────────────────────────

TC1_BASIC = (
    "TC1 — Basic DNA Analysis",
    """\
GENE x = "ATCGATCG"

STUDY x:
    RNA_TRANSCRIBE
    GC_CONTENT
    LENGTH
    REPORT "analysis complete"
END
"""
)

TC2_MULTIPLY = (
    "TC2 — MULTIPLY Operation",
    """\
GENE x = "ATCG"

STUDY x:
    MULTIPLY 2
    LENGTH
END
"""
)

TC3_ADD = (
    "TC3 — ADD Two Genes",
    """\
GENE x = "ATCG"
GENE y = "GGGG"

STUDY x:
    ADD y
    LENGTH
    GC_CONTENT
END
"""
)

TC4_ALL_OPS = (
    "TC4 — All Operations",
    """\
GENE x = "ATCG"
GENE y = "GGGG"

STUDY x:
    MULTIPLY 2
    ADD y
    SUBTRACT 2
    RNA_TRANSCRIBE
    LENGTH
    GC_CONTENT
    REPORT "done"
END
"""
)

TC5_CONDITIONAL = (
    "TC5 — Conditional Statement",
    """\
GENE x = "GGGGCCCC"

STUDY x:
    GC_CONTENT
    IF gc_content > 60 THEN
        REPORT "high GC content"
    END
END
"""
)

# ─────────────────────────────────────────────────────────────────────
# ERROR TESTS (Expected to fail - testing error handling)
# ─────────────────────────────────────────────────────────────────────

TC6_INVALID_DNA = (
    "TC6 — Invalid DNA sequence (ERROR)",
    """\
GENE x = "ATCGZ"

STUDY x:
    LENGTH
END
"""
)

TC7_UNDECLARED_GENE = (
    "TC7 — STUDY undeclared gene (ERROR)",
    """\
STUDY ghost:
    LENGTH
END
"""
)

TC8_MISSING_QUOTES = (
    "TC8 — Missing quotes (ERROR)",
    """\
GENE x = ATCG

STUDY x:
    LENGTH
END
"""
)

TC9_SUBTRACT_TOO_MANY = (
    "TC9 — SUBTRACT too many bases (ERROR)",
    """\
GENE x = "ATCG"

STUDY x:
    SUBTRACT 10
END
"""
)

TC10_DIVIDE_NOT_EVEN = (
    "TC10 — DIVIDE not divisible (ERROR)",
    """\
GENE x = "ATCGATCG"

STUDY x:
    DIVIDE 3
END
"""
)

TC11_DUPLICATE_GENE = (
    "TC11 — Duplicate gene (ERROR)",
    """\
GENE x = "ATCG"
GENE x = "GGGG"

STUDY x:
    LENGTH
END
"""
)

TC12_MISSING_COLON = (
    "TC12 — Missing colon (ERROR)",
    """\
GENE x = "ATCG"
STUDY x
    LENGTH
END
"""
)

TC13_MISSING_END = (
    "TC13 — Missing END (ERROR)",
    """\
GENE x = "ATCG"

STUDY x:
    LENGTH
"""
)

TC14_ZERO_MULTIPLY = (
    "TC14 — MULTIPLY by zero (ERROR)",
    """\
GENE x = "ATCG"

STUDY x:
    MULTIPLY 0
END
"""
)

TC15_INVALID_CONDITION = (
    "TC15 — Invalid IF variable (ERROR)",
    """\
GENE x = "ATCG"

STUDY x:
    IF temperature > 50 THEN
        REPORT "hot"
    END
END
"""
)


# ─────────────────────────────────────────────────────────────────────
# ALL TEST CASES
# ─────────────────────────────────────────────────────────────────────

ALL_TEST_CASES = [
    # Working tests (5)
    TC1_BASIC,
    TC2_MULTIPLY,
    TC3_ADD,
    TC4_ALL_OPS,
    TC5_CONDITIONAL,
    
    # Error tests (10)
    TC6_INVALID_DNA,
    TC7_UNDECLARED_GENE,
    TC8_MISSING_QUOTES,
    TC9_SUBTRACT_TOO_MANY,
    TC10_DIVIDE_NOT_EVEN,
    TC11_DUPLICATE_GENE,
    TC12_MISSING_COLON,
    TC13_MISSING_END,
    TC14_ZERO_MULTIPLY,
    TC15_INVALID_CONDITION,
]