"""
parser.py - Phase 2: Syntax Analysis
"""

from dataclasses import dataclass, field
from typing import Optional
from lexer import Token


@dataclass
class ASTNode:
    pass


@dataclass
class GeneDecl(ASTNode):
    name: str
    sequence: str


@dataclass
class RNATranscribeNode(ASTNode):
    pass


@dataclass
class GCContentNode(ASTNode):
    pass


@dataclass
class LengthNode(ASTNode):
    pass


@dataclass
class ReportNode(ASTNode):
    message: str


@dataclass
class MultiplyNode(ASTNode):
    count: int


@dataclass
class AddNode(ASTNode):
    gene_name: str


@dataclass
class SubtractNode(ASTNode):
    count: int


@dataclass
class DivideNode(ASTNode):
    parts: int


@dataclass
class ConditionalNode(ASTNode):
    variable: str
    operator: str
    value: float
    body: ASTNode


@dataclass
class StudyBlock(ASTNode):
    target: str
    statements: list[ASTNode] = field(default_factory=list)


@dataclass
class ProgramNode(ASTNode):
    genes: list[GeneDecl] = field(default_factory=list)
    studies: list[StudyBlock] = field(default_factory=list)


class ParseError(Exception):
    def __init__(self, message: str, line: int = -1, col: int = -1):
        self.message = message
        self.line = line
        self.col = col
        if line > 0:
            super().__init__(f"Line {line}, col {col}: {message}")
        else:
            super().__init__(message)


class Parser:
    SYNC_TOKENS = {'GENE', 'STUDY', 'END'}

    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0
        self.errors = []

    def peek(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return Token('EOF', '', -1, -1)

    def advance(self) -> Token:
        tok = self.peek()
        self.pos += 1
        return tok

    def expect(self, ttype: str) -> Optional[Token]:
        tok = self.peek()
        if tok.type == ttype:
            return self.advance()
        self.errors.append(ParseError(
            f"Expected '{ttype}' but got '{tok.type}' (value: '{tok.value}')",
            tok.line, tok.col
        ))
        return None

    def expect_keyword(self, kw: str) -> Optional[Token]:
        tok = self.peek()
        if tok.type == 'KEYWORD' and tok.value == kw:
            return self.advance()
        self.errors.append(ParseError(
            f"Expected keyword '{kw}' but got '{tok.value}'",
            tok.line, tok.col
        ))
        return None

    def match_keyword(self, kw: str) -> bool:
        tok = self.peek()
        return tok.type == 'KEYWORD' and tok.value == kw

    def parse(self) -> ProgramNode:
        program = ProgramNode()

        while self.peek().type != 'EOF':
            if self.match_keyword('GENE'):
                program.genes.append(self.parse_gene_decl())
            elif self.match_keyword('STUDY'):
                program.studies.append(self.parse_study())
            else:
                tok = self.peek()
                if tok.type != 'EOF':
                    self.errors.append(ParseError(
                        f"Unexpected '{tok.value}'. Expected GENE or STUDY",
                        tok.line, tok.col
                    ))
                self.advance()

        return program

    def parse_gene_decl(self) -> GeneDecl:
        self.expect_keyword('GENE')
        name_tok = self.expect('IDENTIFIER')
        self.expect('ASSIGN')
        
        tok = self.peek()
        if tok.type == 'IDENTIFIER':
            self.errors.append(ParseError(
                f"DNA sequence must be in quotes: \"{tok.value}\"",
                tok.line, tok.col
            ))
            self.advance()
            return GeneDecl(
                name=name_tok.value if name_tok else '?',
                sequence=''
            )
        
        seq_tok = self.expect('DNA_LITERAL')
        
        if name_tok and seq_tok:
            return GeneDecl(
                name=name_tok.value,
                sequence=seq_tok.value.strip('"')
            )
        
        return GeneDecl(
            name=name_tok.value if name_tok else '?',
            sequence=seq_tok.value.strip('"') if seq_tok else ''
        )

    def parse_study(self) -> StudyBlock:
        self.expect_keyword('STUDY')
        target_tok = self.expect('IDENTIFIER')
        
        if not target_tok:
            return StudyBlock(target='?')
        
        tok = self.peek()
        if tok.type != 'COLON':
            self.errors.append(ParseError(
                f"Missing colon after STUDY '{target_tok.value}'",
                tok.line, tok.col
            ))
        
        self.expect('COLON')
        target = target_tok.value
        block = StudyBlock(target=target)

        while not self.match_keyword('END') and self.peek().type != 'EOF':
            stmt = self.parse_statement()
            if stmt:
                block.statements.append(stmt)

        if not block.statements:
            self.errors.append(ParseError(
                f"STUDY '{target}' has no statements",
                self.peek().line, self.peek().col
            ))

        self.expect_keyword('END')
        return block

    def parse_statement(self) -> Optional[ASTNode]:
        tok = self.peek()

        if tok.type not in ('KEYWORD', 'IDENTIFIER'):
            self.errors.append(ParseError(
                f"Expected statement keyword, got '{tok.value}'",
                tok.line, tok.col
            ))
            self.advance()
            return None

        if tok.value == 'RNA_TRANSCRIBE':
            self.advance()
            return RNATranscribeNode()

        elif tok.value == 'GC_CONTENT':
            self.advance()
            return GCContentNode()

        elif tok.value == 'LENGTH':
            self.advance()
            return LengthNode()

        elif tok.value == 'REPORT':
            self.advance()
            msg_tok = self.peek()
            if msg_tok.type in ('STRING', 'DNA_LITERAL'):
                self.advance()
                return ReportNode(message=msg_tok.value.strip('"'))
            else:
                self.errors.append(ParseError(
                    f"Expected string after REPORT but got '{msg_tok.value}'",
                    msg_tok.line, msg_tok.col
                ))
                return ReportNode(message='')

        elif tok.value == 'MULTIPLY':
            self.advance()
            num_tok = self.expect('NUMBER')
            if num_tok:
                return MultiplyNode(count=int(float(num_tok.value)))
            return None

        elif tok.value == 'ADD':
            self.advance()
            gene_tok = self.expect('IDENTIFIER')
            if gene_tok:
                return AddNode(gene_name=gene_tok.value)
            return None

        elif tok.value == 'SUBTRACT':
            self.advance()
            num_tok = self.expect('NUMBER')
            if num_tok:
                return SubtractNode(count=int(float(num_tok.value)))
            return None

        elif tok.value == 'DIVIDE':
            self.advance()
            num_tok = self.expect('NUMBER')
            if num_tok:
                return DivideNode(parts=int(float(num_tok.value)))
            return None

        elif tok.value == 'IF':
            return self.parse_conditional()

        else:
            self.errors.append(ParseError(
                f"Unknown statement '{tok.value}'",
                tok.line, tok.col
            ))
            self.advance()
            return None

    def parse_conditional(self) -> ConditionalNode:
        self.expect_keyword('IF')
        var_tok = self.expect('IDENTIFIER')
        op_tok = self.expect('OPERATOR')
        val_tok = self.expect('NUMBER')
        self.expect_keyword('THEN')
        body = self.parse_statement()
        self.expect_keyword('END')

        return ConditionalNode(
            variable=var_tok.value if var_tok else '?',
            operator=op_tok.value if op_tok else '?',
            value=float(val_tok.value) if val_tok else 0.0,
            body=body or ReportNode(message='')
        )