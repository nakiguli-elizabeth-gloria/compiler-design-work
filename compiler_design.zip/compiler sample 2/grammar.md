Program → { GeneDecl | StudyBlock }

GeneDecl → GENE IDENTIFIER = DNA_LITERAL

StudyBlock → STUDY IDENTIFIER : { Statement } END

Statement → RNA_TRANSCRIBE
| GC_CONTENT
| LENGTH
| REPORT string
| MULTIPLY number
| ADD IDENTIFIER
| SUBTRACT number
| DIVIDE number
| IF IDENTIFIER operator number THEN Statement END

operator → > | < | >= | <= | == | !=

text

## FIRST Sets
FIRST(Program) = { GENE, STUDY }
FIRST(GeneDecl) = { GENE }
FIRST(StudyBlock) = { STUDY }
FIRST(Statement) = { RNA_TRANSCRIBE, GC_CONTENT, LENGTH, REPORT,
MULTIPLY, ADD, SUBTRACT, DIVIDE, IF }
FIRST(Conditional) = { IF }
FIRST(operator) = { >, <, >=, <=, ==, != }

text

## FOLLOW Sets
FOLLOW(GeneDecl) = { GENE, STUDY, EOF }
FOLLOW(StudyBlock) = { GENE, STUDY, EOF }
FOLLOW(Statement) = { RNA_TRANSCRIBE, GC_CONTENT, LENGTH, REPORT,
MULTIPLY, ADD, SUBTRACT, DIVIDE, IF, END }
FOLLOW(Conditional) = { RNA_TRANSCRIBE, GC_CONTENT, LENGTH, REPORT,
MULTIPLY, ADD, SUBTRACT, DIVIDE, IF, END }

text

## Keywords
GENE, STUDY, RNA_TRANSCRIBE, GC_CONTENT, LENGTH,
IF, THEN, END, REPORT, MULTIPLY, ADD, SUBTRACT, DIVIDE

text

## Operators
= : > < >= <= == !=

text

## Valid DNA Bases
A T C G

text

## Condition Variables
gc_content, length

text

## Example Code
GENE Aisha = "ATCG"
  GENE Allan = "ATCGG"
  STUDY Aisha:
      MULTIPLY 2
      ADD Allan
      GC_CONTENT
      IF gc_content > 50 THEN
          REPORT "high"
      END
  END



